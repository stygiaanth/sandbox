# Nginx trial
Following file provides a little description and screen picture proves taht task was completed


### Required software
In order to launch created helm chart, docker desktop, minikube and helm were used. For the testing purposes, several mock services were deployed. For local testing it's also required to populate hosts file with test apps' hostnames.

- 127.0.0.1   app1.local
- 127.0.0.1   app2.local
- 127.0.0.1   ignore.local

### Variables for chart
There are no required variables (is done for simplicity). All variables have default values which are set according to task description

### Proves
Attaching screens with description here, but they can also be viewed in screens/ directory of the archive

1. Deploy helm chart using following command
```
helm install my-nginx-ingress ./nginx-ingress
```
![alt text](screens/resources_deployed.png)


2. Use following command to validate successfull deployment of main resources
```
kubectl get services,deployments,ingressclasses -n infra-nginx-ingress-trial
```
![alt text](screens/check_resources_deployed.png)

3. View test services. It can be seen, that there are 3 ingresses, two of which have required class specified. The third should be ignored by the controller
```
kubectl get services,deployments,ingresses -n nginx-trial-test-apps
```
![alt text](screens/check_test_resources_deployed.png)

4. View controller pods
```
kubectl get pods -n infra-nginx-ingress-trial
```
![alt text](screens/view_controller_pods.png)

5. Check pod logs to verify that controller sees deployed test ingresses with required class
```
kubectl logs infra-nginx-ingress-trial-758cf4fd55-v2cqk -n infra-nginx-ingress-trial
```
![alt text](screens/nginx_controller_logs.png)

6. Forward controller ports for test purposes
```
kubectl port-forward -n infra-nginx-ingress-trial svc/infra-nginx-ingress-trial 8080:80
```
![alt text](screens/port_forward.png)

7. Check the first two apps are accesible in browser, and the third one shouldn't be working
![alt text](screens/app1_working.png)

![alt text](screens/app2_working.png)

![alt text](screens/app3_not_working.png)
